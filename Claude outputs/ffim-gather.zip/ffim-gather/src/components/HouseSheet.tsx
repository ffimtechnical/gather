import {
  Church as ChurchIcon,
  CalendarClock, ChevronDown, ChevronUp, Clock, Heart, ListPlus, MoreHorizontal, Navigation, Pencil, Phone,
  MessageSquare, UserPlus, Users, X,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useBranding } from '../branding';
import { routeToChurch } from '../churchDistance';
import type { Route } from '../routing';
import { OUTCOMES, TASK_ACTIONS, VISIT_KINDS, type House, type Person, type Task, type Visit } from '../../shared/model';
import { quickLog, kindFor } from '../actions';
import { blankPerson, blankVisit } from '../db';
import { ACTION_ICON, ICON, ICON_SM, KIND_ICON, OUTCOME_ICON } from '../icons';
import { Action, Avatar, StatusTag, useUI } from '../ui';
import { directionsUrl, distanceM, dueLabel, fmtDateTime, fmtDistance, phoneLinks, timeAgo } from '../util';
import { AssignModal } from './AssignModal';
import { HouseForm } from './HouseForm';
import { PersonForm } from './PersonForm';
import { VisitForm } from './VisitForm';

const QUICK = ['prayed', 'good_chat', 'invited', 'not_home'];

export function HouseSheet() {
  const { data, selectedId, select } = useUI();
  const [expanded, setExpanded] = useState(false);
  const house = selectedId ? data.houseById.get(selectedId) : undefined;
  useEffect(() => setExpanded(false), [selectedId]);
  if (!house) return null;
  return (
    <div className={`sheet ${expanded ? 'expanded' : ''}`}>
      <button className="sheet-handle" onClick={() => setExpanded(!expanded)} aria-label={expanded ? 'Show less' : 'Show more'}>
        {expanded ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
      </button>
      <HouseDetails key={house.id} house={house} onClose={() => select(null)} />
    </div>
  );
}

function HouseDetails({ house, onClose }: { house: House; onClose: () => void }) {
  const ui = useUI();
  const { data, openModal, me } = ui;
  const status = data.statusById.get(house.id)!;
  const people = data.peopleByHouse.get(house.id) ?? [];
  const visits = data.visitsByHouse.get(house.id) ?? [];
  const tasks = data.openTasksByHouse.get(house.id) ?? [];
  const members = people.filter((p) => p.is_member).length;
  const phone = people.find((p) => p.phone)?.phone;
  const zone = house.zone_id ? data.zoneById.get(house.zone_id) : undefined;
  const [showAll, setShowAll] = useState(false);

  const fullLog = () => openModal(<VisitForm visit={{ ...blankVisit(house.id), kind: kindFor(status) }} house={house} isNew />);

  return (
    <div className="sheet-body">
      <header className="house-head">
        <div className="grow">
          <StatusTag status={status} />
          <h2>{house.name || house.address || house.code}</h2>
          <div className="meta">
            {(house.name || house.address) && <span className="code">{house.code}</span>}
            {zone && (
              <span className="meta-item">
                <span className="swatch" style={{ background: zone.color }} />
                {zone.name}
              </span>
            )}
            {me && <span className="meta-item">{fmtDistance(distanceM(me, house))}</span>}
          </div>
        </div>
        <button className="icon-btn" onClick={onClose} aria-label="Close">
          <X {...ICON} />
        </button>
      </header>

      <div className="stat-row">
        <span title="People living here">
          <Users {...ICON_SM} />
          {house.household_size ?? people.length}
        </span>
        <span title="Members" className={members ? 'pos' : ''}>
          <Heart {...ICON_SM} />
          {members}
        </span>
        <span title="Last spoke with someone">
          <Clock {...ICON_SM} />
          {timeAgo(data.lastContactById.get(house.id))}
        </span>
        <ChurchDistance house={house} />
        {house.next_visit_on && (
          <span title="Planned visit" className={dueLabel(house.next_visit_on)?.late ? 'late' : ''}>
            <CalendarClock {...ICON_SM} />
            {dueLabel(house.next_visit_on)?.text}
          </span>
        )}
      </div>

      {tasks.map((t) => (
        <TaskLine key={t.id} t={t} />
      ))}

      {status !== 'dnv' && (
        <div className="quick-log" role="group" aria-label="Log a visit">
          {QUICK.map((o) => {
            const info = OUTCOMES.find((x) => x.value === o)!;
            const Icon = OUTCOME_ICON[o];
            return (
              <button key={o} className="ql" onClick={() => void quickLog(ui, house, o)}>
                <Icon {...ICON} />
                <span>{info.label}</span>
              </button>
            );
          })}
          <button className="ql" onClick={fullLog} aria-label="More visit details">
            <MoreHorizontal {...ICON} />
            <span>More</span>
          </button>
        </div>
      )}

      <div className="actions">
        {phone && <Action icon={Phone} label="Call" href={phoneLinks(phone).tel} />}
        {phone && <Action icon={MessageSquare} label="WhatsApp" href={phoneLinks(phone).whatsapp} />}
        <Action icon={Navigation} label="Go" href={directionsUrl(house.lat, house.lng)} />
        <Action icon={UserPlus} label="Person" onClick={() => openModal(<PersonForm person={blankPerson(house.id)} isNew />)} />
        {data.perms.assign && <Action icon={ListPlus} label="Assign" onClick={() => openModal(<AssignModal houseIds={[house.id]} />)} />}
        <Action icon={Pencil} label="Edit" onClick={() => openModal(<HouseForm house={house} onDeleted={onClose} />)} />
      </div>

      {people.length > 0 && (
        <section>
          {people.map((p) => (
            <PersonRow key={p.id} p={p} />
          ))}
        </section>
      )}

      {house.description && <p className="note">{house.description}</p>}

      {visits.length > 0 && (
        <section className="timeline">
          {(showAll ? visits : visits.slice(0, 4)).map((v) => (
            <VisitRow key={v.id} v={v} house={house} people={people} />
          ))}
          {visits.length > 4 && !showAll && (
            <button className="link" onClick={() => setShowAll(true)}>
              All {visits.length} visits
            </button>
          )}
        </section>
      )}
    </div>
  );
}

function ChurchDistance({ house }: { house: House }) {
  const { church } = useBranding();
  const { showRoute } = useUI();
  const [r, setR] = useState<Route | null | undefined>(undefined);
  useEffect(() => {
    let alive = true;
    setR(undefined);
    routeToChurch(house)?.then((x) => alive && setR(x));
    return () => {
      alive = false;
    };
  }, [house, church]);
  if (!church) return null;
  if (r === undefined) {
    return (
      <span title="Distance to church" className="muted">
        <ChurchIcon {...ICON_SM} />…
      </span>
    );
  }
  const km = (m: number) => (m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`);
  return (
    <button
      className="stat-btn"
      title={r ? `${km(r.meters)} by road, ${r.minutes} min walk. Tap to see the route.` : 'No road route found'}
      onClick={() => r && showRoute(r.path)}
    >
      <ChurchIcon {...ICON_SM} />
      {r ? `${km(r.meters)}, ${r.minutes} min` : '—'}
    </button>
  );
}

function TaskLine({ t }: { t: Task }) {
  const { data } = useUI();
  const Icon = ACTION_ICON[t.action];
  const who = t.assignee_id ? data.userById.get(t.assignee_id) : undefined;
  const due = dueLabel(t.due_on);
  return (
    <div className="task-line">
      <Icon {...ICON_SM} />
      <b>{TASK_ACTIONS.find((a) => a.value === t.action)?.label}</b>
      {due && <span className={`due ${due.late ? 'late' : ''}`}>{due.text}</span>}
      <span className="grow" />
      {who && (
        <span className="who">
          <Avatar user={who} size={22} />
          {who.id === data.me.id ? 'You' : who.name.split(' ')[0]}
        </span>
      )}
    </div>
  );
}

function PersonRow({ p }: { p: Person }) {
  const { openModal } = useUI();
  const links = p.phone ? phoneLinks(p.phone) : null;
  return (
    <div className="row-item">
      <button className="row-main" onClick={() => openModal(<PersonForm person={p} />)}>
        <Avatar name={p.full_name} size={36} />
        <span className="row-text">
          <b>
            {p.full_name || 'Unnamed'}
            {p.is_member && <Heart size={14} strokeWidth={2.2} className="member-heart" aria-label="Member" />}
          </b>
          {p.phone && <small>{p.phone}</small>}
        </span>
      </button>
      {links && (
        <a className="icon-btn" href={links.tel} aria-label={`Call ${p.full_name}`}>
          <Phone {...ICON_SM} />
        </a>
      )}
    </div>
  );
}

function VisitRow({ v, house, people }: { v: Visit; house: House; people: Person[] }) {
  const { openModal } = useUI();
  const outcome = OUTCOMES.find((o) => o.value === v.outcome);
  const Icon = (v.outcome && OUTCOME_ICON[v.outcome]) || KIND_ICON[v.kind];
  const who = people.find((p) => p.id === v.person_id)?.full_name;
  return (
    <button className="visit-row" onClick={() => openModal(<VisitForm visit={v} house={house} />)}>
      <span className="visit-icon">
        <Icon {...ICON_SM} />
      </span>
      <span className="row-text">
        <b>{outcome?.label ?? VISIT_KINDS.find((k) => k.value === v.kind)?.label}</b>
        <small title={fmtDateTime(v.visited_at)}>
          {timeAgo(v.visited_at)}
          {v.visited_by && `, ${v.visited_by}`}
          {who && ` with ${who}`}
        </small>
        {v.notes && <span className="visit-notes">{v.notes}</span>}
      </span>
    </button>
  );
}
